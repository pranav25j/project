package Project;
import java.util.Scanner;

public class Main {
	
	
	 public static void main(String[] args) 
	    {  
	        //create a DoublyLinkedList object
	        GateManagement dl_List = new GateManagement();  

	        Scanner user_input = new Scanner(System.in);

	        String adminId,adminPassword,employeeId,employeePassword,employeeNumber,employeeStatus,employeeName;
           
	      //==============================ADMIN ACCESS==========================================//
	    	
	        do {
	        	System.out.println("\n__________________________________________________________________________");
	        	System.out.println("\n______________________~*~ GATE MANAGEMENT SYSTEM ~*~______________________");
	         	System.out.println("\n__________________________________________________________________________");
	        	System.out.println("\n----Admin Login----");
	            System.out.println("\nEnter Administration ID :- ");
	            adminId = user_input.nextLine();
	            System.out.println("Enter Administration Password :- ");
	            adminPassword = user_input.nextLine();
	            if(adminId.equals("admin") && adminPassword.equals("admin")){
	                break;
	            }
	            else{
	                System.out.println("\n\n\n Login Failed\nEntered Administration ID and Password is wrong\n\n\n");
	            }
	           
	        }while(true);

	      //==============================ALL MENU OPTIONS==========================================//
	        int menuOption;
	    do{
	    	System.out.println("\n=======*/MENU OPTIONS/*========");
	        System.out.println("\n1. Add Employee");
	        System.out.println("2. Edit Employee Details");
	        System.out.println("3. Delete Employee");
	        System.out.println("4. Enter Employee ID and Password to open the gate");
	        System.out.println("5. Enter Employee ID to close the gate");
	        System.out.println("6. Check the Status of employee");
	        System.out.println("7. Find Employee Details");
	        System.out.println("8. Exit");
	        System.out.println("\n=======*/SELECT THE OPTION/*========");
	        menuOption = user_input.nextInt();

	        switch(menuOption) {
	            case 1:
	                System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	                System.out.println("\n========*/NEW PROFILE CREATION/*========");
	                String id = dl_List.setUniqueID();
	                System.out.println("\nEmployee ID :- " + id);
	                employeeId = user_input.nextLine();
	                System.out.println("\nEnter Employee Name :- ");
	                employeeName = user_input.nextLine();
	                System.out.println("Enter Employee Password :- ");
	                employeePassword = user_input.nextLine();
	                System.out.println("Enter Employee Mobile Number :- ");
	                employeeNumber = user_input.nextLine();
	                System.out.println("Enter Employee Status :- ");
	                employeeStatus = user_input.nextLine();
	                dl_List.addEmployee(id,employeeName,employeeNumber,employeePassword,employeeStatus);
	                break;
	            
	            case 2:
	                System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	                System.out.println("\n========*/EDIT DETAILS/*========");
	                System.out.println("Enter the Employee ID you want to Edit :- ");
	                employeeId=user_input.nextLine();
	                employeeId=user_input.nextLine();
	                dl_List.editEmployeeInfo(employeeId);
	            break;
	            
	            case 3:
	                     System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	                     System.out.println("\n================");
	                     System.out.println("Enter the Employee ID you want to Delete :- ");
	                     employeeId=user_input.nextLine();
	                     employeeId=user_input.nextLine();
	                     dl_List.deleteEmplyoeeInfoBeg(employeeId);
	                     dl_List.deleteEmplyoeeInfoEnd(employeeId);
	                 break;
	                 
	   
	            case 4:
	                System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	                System.out.println("\n========*/OPEN GATE ACCESS/*========");
	                System.out.println("\nEnter the Employee ID:- ");
	                employeeId=user_input.nextLine();
	                employeeId=user_input.nextLine();
	                System.out.println("Enter the Employee Password:- ");
	                employeePassword=user_input.nextLine();
	                dl_List.grantAccess(employeeId,employeePassword);
	            break;
	            case 5:
	                System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	                System.out.println("\n========*/CLOSE GATE ACCESS/*========");
	                System.out.println("\nEnter the Employee ID:- ");
	                employeeId=user_input.nextLine();
	                employeeId=user_input.nextLine();
	                dl_List.takeAccess(employeeId);
	            break;
	             
	            case 6:
	            	 System.out.println("\n========*/CHECK STATUS/*========");
		             dl_List.printNodes();
	                break;
	            case 7:
	                System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	                System.out.println("\n========*/SEARCH EMPLOYEE/*========");
	                System.out.println("\nEnter the Employee ID:- ");
	                employeeId=user_input.nextLine();
	                employeeId=user_input.nextLine();
	                dl_List.findEmplyoeeInfo(employeeId);
	                break;
	            case 8:
	            	System.out.println("You have successfully exited.");
	        }
	    }while(menuOption!=8);
	       
	      
	} 
	}

//==============================END==========================================//

