package Project;

import java.util.*; 
import java.text.DateFormat;  
import java.text.SimpleDateFormat;

public class GateManagement {
	

	
	    //A node class for doubly linked list
	    class Node{  
	    	
	        String employee_id ;
			String employee_name,employee_mobile_no,employee_password,employee_status;  
	        Node previous;  
	        Node next;
			public Object current;  
	        
	        
	        public Node(String employee_id,String employee_name,String employee_mobile_no,String employee_password,String employee_status) {  
	            this.employee_id = employee_id;
	            this.employee_mobile_no=employee_mobile_no;
	            this.employee_name=employee_name;
	            this.employee_password=employee_password;
	            this.employee_status=employee_status;
	        }  
	    }  
	    //Initially, head and tail is set to null
	    
	    
	    Node head,tail = null;
	    
	  //==============================SET UNIQUE ID==========================================//
		
	   public String  setUniqueID(){
	    Date date = Calendar.getInstance().getTime();  
	    DateFormat dateFormat = new SimpleDateFormat("mmss");  
	    String employeeId = "00"+dateFormat.format(date); 
	    return employeeId;   
	}

	 //==============================ADD A NODE TO THE LIST==========================================//
		
	    
	    public void addEmployee(String employee_id,String employee_name,String employee_mobile_no,String employee_password,String employee_status){  
	        //Create a new node  
	        Node newNode = new Node(employee_id,employee_name,employee_mobile_no,employee_password,employee_status);  
	   
	        //if list is empty, head and tail points to newNode  
	        if(head == null) {  
	            head = tail = newNode;  
	            //head's previous will be null  
	            head.previous = null;  
	            //tail's next will be null  
	            tail.next = null;  
	        }  
	        else {  
	            //add newNode to the end of list. tail->next set to newNode  
	            tail.next = newNode;  
	            //newNode->previous set to tail  
	            newNode.previous = tail;  
	            //newNode becomes new tail  
	            tail = newNode;  
	            //tail's next point to null  
	            tail.next = null;  
	        }  
	    } 
	    
	    
	  //==============================EDIT EMPLOYEE INFORMATION==========================================//
	
	    
	    public void editEmployeeInfo(String employee_id) 
	{
	    Scanner user_input = new Scanner(System.in);
	  
	    //Node current will point to head  
	    Node current = head;  
	    System.out.println(employee_id);
	    if(head == null) 
	    {  
	        System.out.println("There is no data");  
	        return;  
	    }  
	    int flag=0;
	    while(current != null)
	    {  
	        //Print each node and then go to next. 
	        if(current.employee_id.equals(employee_id)){
	            flag=0;
	            System.out.println("\n\nEmployee Details are .......\n\n");
	            System.out.println("\nEmployee ID :- \n" + current.employee_id);
	            System.out.println( "Employee Name :- " + current.employee_name);
	            System.out.println(  "Employee Mobile number :- " + current.employee_mobile_no);
	            System.out.println("\n\nEdit Employee Details \n ");
	            System.out.println("Enter Employee Name :- ");
	            current.employee_name = user_input.nextLine();
	            System.out.println("Enter Employee Password :- ");
	            current.employee_password = user_input.nextLine();
	            System.out.println("Enter Employee mobile Number :- ");
	            current.employee_mobile_no = user_input.nextLine();

	            break;
	        }
	        else
	        {
	            flag=1;
	        }
	        current = current.next;  
	    }

	    if(flag==1)
	    {
	        System.out.println("Employee Details not found");
        }

	}
	    
	  //==============================DELETION==========================================//


	  	public void deleteEmplyoeeInfoBeg(String employee_id) {
	  		int length = 0;
	  	     Scanner user_input = new Scanner(System.in);
	  	     Node n = head;
	  	     if(head == null)
	  	     {
	  	    	 System.out.println("List is empty");
	  	     }
	  	     else {
	  	    	 head = n.next;
	  	    	 head.previous = null;
	  	     }
	  	     length--;
	  	}
	  	public void deleteEmplyoeeInfoEnd(String employee_id) {
	  		int length = 0;
	  	     Scanner user_input = new Scanner(System.in);
	  	    
	  	     if(head == null)
	  	     {
	  	    	 System.out.println("List is empty");
	  	     }
	  	     else {
	  	    	 Node n = head;
	  	    	 while(n.next.next != null)
	  	    		 n = n.next;
	  	     
	  	     n.next.previous = null;
	  	     n.next = null;
	  	     
	  	     length--;
	  	     }
	  	     }
	  	     
	  	     
//==============================OPEN GATE ACCESS==========================================//
	
	public void grantAccess(String employee_id,String employee_password) {
	
		//Node current will point to head  
	    Node current = head;  
	    if(head == null) 
	    {  
	        System.out.println("There is no data");  
	        return;  
	    }  
	    int flag=0;
	    while(current != null)
	    {  
	        //Print each node and then go to next. 
	        if(current.employee_id.equals(employee_id) && current.employee_password.equals(employee_password) ){
	            flag=0;
	            if (current.employee_status.equals("IN")){
	                System.out.println("\n\n-:Employee has already Granted IN Access:-\n\n");
	            }
	            else
	            {
	            	 System.out.println("\n\n-:Employee Access Granted:-\n\n");
	            	 System.out.println("\n========*/WELCOME TO CDAC MUMBAI/*========");
	                 current.employee_status="IN";
	            }
	            

	            break;
	        }
	        else
	        {
	            flag=1;
	        }
	        current = current.next;  
	    }

	    if(flag==1)
	    {
	     
	            System.out.println("Employee Details not found ||| password or loging id is wrong");
	    }
     }

	
	//==============================CLOSE GATE ACCESS==========================================//
	
	public void takeAccess(String employee_id) {
      //Node current will point to head  
	    Node current = head;  
	    if(head == null) {  
	    System.out.println("There is no data");  
	        return;  
	    }  
	    int flag=0;
	    while(current != null) {  
	        //Print each node and then go to next. 
	        if(current.employee_id.equals(employee_id)){
	            flag=0;
	            if (current.employee_status.equals("OUT")){
	                System.out.println("\n-:Employee has already Granted OUT Access:-\n");
	            }
	            else{
	            	System.out.println("\n\nEmployee is Allowed to go OUT \n\n");
	                System.out.println("\n========*/THANKS TO VISIT/*========");
	                current.employee_status="OUT";
	            }
	            

	            break;
	        }
	        else{
	            flag=1;
	        }
	        current = current.next;  
	    }

	    if(flag==1){
	       
	            System.out.println("-:Employee Details not found try again:-");
	    }  
	}

	
	//==============================CHECK AND PRINT ALL NODES OF DLL==========================================//


	    public void printNodes() {  
	        //Node current will point to head  
	        Node current = head;  
	        if(head == null) {  
	            System.out.println("-:Employee Details not found:-");  
	            return;  
	        }  
	        System.out.println("Status Of employee: ");  
	        while(current != null) {  
	            //Print each node and then go to next.  
	            System.out.println("\nEmployee Id:- " +current.employee_id +   "\nEmployee Mobile No.:- " + current.employee_mobile_no + "\nEmployee Name:- " + current.employee_name + "\nEmployee Status:- "+ current.employee_status);  
	            current = current.next;  
	        }
	    }  
	
	
	    //==============================SEARCH AND PRINT EMPLOYEE INFORMATION==========================================//
	
	
	public void findEmplyoeeInfo(String employee_id) {  
	    //Node current will point to head  
	    Node current = head;  
	    
	    if(head == null) {  
	        System.out.println("-:Employee Details is empty:-");  
	        return;  
	    }  
	    int flag=0;
	    while(current != null) {  
	        //Print each node and then go to next. 
	        if(current.employee_id.equals(employee_id)){
	            flag=0;
	            System.out.println("Employee Details are .......");
	            System.out.println("\nEmployee ID :- " + current.employee_id);
	            System.out.println("Employee Name :- " + current.employee_name);
	            System.out.println("Employee Mobile number :- " + current.employee_mobile_no);
	            System.out.println("Employee Password :-  "+ current.employee_password);
	            System.out.println("Employee Status :- " + current.employee_status);

	            break;
	        }
	        else{
	            flag=1;
	        }
	        current = current.next;  
	    }

	    if(flag==1){
	        System.out.println("Employee Details not found");

	    }
	}
}

//==============================CONTINUE==========================================//

	  
